using System;

namespace GildedRose
{
    public class Shop
    {
        public static void UpdateQuality()
        {
            throw new NotImplementedException();
        }
    }
}