namespace GildedRose.Items
{
    public class LegendaryItem : Item
    {
         public LegendaryItem(string name, int sellIn, int quality)
            : base(name, sellIn, quality)
        { }

        public override void Update()
        { }
        

    }
}